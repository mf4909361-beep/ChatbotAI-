// ChatBot AI backend (Node.js)
// Keep API key in .env, never in frontend HTML.
import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
dotenv.config();

const app = express();
app.use(express.json({ limit: "1mb" }));
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/api/chat", async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const safeMessages = messages
      .filter(m => ["user", "assistant"].includes(m?.role) && typeof m?.content === "string")
      .slice(-20);
    if (!safeMessages.length) return res.status(400).json({ error: "No messages provided." });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      input: safeMessages
    });
    res.json({ reply: response.output_text || "No text response returned." });
  } catch (err) {
    console.error("API request failed:", err?.message);
    res.status(500).json({ error: "AI request failed. Check server configuration." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ChatBot AI server running on port ${port}`));
