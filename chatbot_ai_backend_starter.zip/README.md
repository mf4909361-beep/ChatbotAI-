# ChatBot AI backend starter

This is a starter server. It does **not** run merely by opening the HTML file in Chrome.

## Setup (on a computer)
1. Install Node.js.
2. Extract this ZIP into a folder.
3. Open terminal in that folder and run: `npm install`
4. Create a `.env` file by copying `.env.example`.
5. Put your API key in `.env`. Do not share it, paste it into HTML, or commit it to Git.
6. Run: `npm start`
7. Server listens on port 3000.

## Frontend integration
Your HTML needs to send chat messages to `POST /api/chat` with JSON:
`{"messages":[{"role":"user","content":"Hello"}]}`
The response is JSON: `{"reply":"..."}`.

This starter is not deployed publicly. Hosting and API billing/permissions are separate steps.
